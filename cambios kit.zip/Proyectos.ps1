# ============================================================
# MODULO: Proyectos.ps1
# Lectura de datos, inicializacion y operaciones de proyectos y componentes SPFx.
# ============================================================

# LECTURA DE DATOS
# ============================================================
# Descripcion: Solicita el nombre de un nuevo proyecto y valida que no exista previamente.
function Read-NewProjectName {
  while ($true) {
    $name = Read-Host "Nombre del nuevo proyecto"
    $name = $name.Trim()

    if (-not (Test-ProjectNameValid -Name $name)) {
      Write-WarnText "Nombre invalido. Usa solo nombre de carpeta, sin rutas."
      continue
    }

    $path = Join-Path $ProjectsRoot $name

    if (Test-Path -LiteralPath $path -PathType Container) {
      Write-WarnText "Ya existe un proyecto con ese nombre: $name"
      continue
    }

    return $name
  }
}
# Descripcion: Solicita el nombre de un componente SPFx.
function Read-ComponentName {
  while ($true) {
    $name = Read-Host "Nombre del componente"
    $name = $name.Trim()

    if (-not [string]::IsNullOrWhiteSpace($name)) {
      return $name
    }

    Write-WarnText "El nombre del componente no puede estar vacio."
  }
}
# Descripcion: Permite seleccionar el tipo de componente SPFx.
function Read-ComponentType {
  Write-Host ""
  Write-Host "Tipo de componente:" -ForegroundColor Yellow
  Write-Host "[1] WebPart"
  Write-Host "[2] Application Customizer"
  Write-Host "[3] Field Customizer"
  Write-Host "[4] Command Set"

  $choice = Read-MenuNumber -Prompt "Selecciona tipo" -Min 1 -Max 4

  switch ($choice) {
    1 {
      return [PSCustomObject]@{
        Label         = "WebPart"
        ComponentType = "webpart"
        ExtensionType = $null
      }
    }
    2 {
      return [PSCustomObject]@{
        Label         = "Application Customizer"
        ComponentType = "extension"
        ExtensionType = "ApplicationCustomizer"
      }
    }
    3 {
      return [PSCustomObject]@{
        Label         = "Field Customizer"
        ComponentType = "extension"
        ExtensionType = "FieldCustomizer"
      }
    }
    4 {
      return [PSCustomObject]@{
        Label         = "Command Set"
        ComponentType = "extension"
        ExtensionType = "ListViewCommandSet"
      }
    }
  }
}

# ============================================================
# INICIALIZACION Y DIAGNOSTICO
# ============================================================
# Descripcion: Inicializa la consola, asegura las carpetas principales y muestra la cabecera.
function Initialize-Console {
  Ensure-Directory -Path $ProjectsRoot
  Ensure-Directory -Path $BaseLibsRoot
  Ensure-Directory -Path $BaseLibsDependencias

  Write-Step "KIT_OFFLINE - Consola de desarrollador"
  # VERIFICACION DE RUTAS
  # Write-Info "KitRoot: $KitRoot"
  # Write-Info "ProjectsRoot: $ProjectsRoot"
  # Write-Info "ScriptsRoot: $ScriptsRoot"
  # Write-Info "BaseRoot: $BaseRoot"
  # Write-Info "BasePackages: $BasePackages"
  # Write-Info "CacheRoot: $CacheRoot"
  # Write-Info "BaseLibsRoot: $BaseLibsRoot"
  # Write-Info "BaseLibsDependencias: $BaseLibsDependencias"
  # Write-Info "YoLocalCmd: $YoLocalCmd"
  # Write-Info "NpmLocalCmd: $NpmLocalCmd"
  # Write-Info "GulpLocalCmd: $GulpLocalCmd"
  # Write-Info "Package base: $PackageBaseJson"
  # Write-Info "Node modules base: $NodeModulesTgz"
}
# Descripcion: Obtiene la lista de proyectos existentes detectando carpetas con package.json.
# Salida: Coleccion de proyectos detectados.
function Get-ProjectCandidates {
  if (-not (Test-Path -LiteralPath $ProjectsRoot -PathType Container)) {
    return @()
  }

  return @(Get-ChildItem -LiteralPath $ProjectsRoot -Directory -ErrorAction SilentlyContinue |
    Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName "package.json") -PathType Leaf } |
    Sort-Object -Property Name)
}

# ============================================================
# LOGICA - NUEVO PROYECTO
# ============================================================
# Descripcion: Valida que existen los elementos necesarios para crear proyectos.
function Test-NewProjectPrerequisites {
  Throw-IfMissingFile -Path $YoLocalCmd -Label "yo-local.cmd"
  Throw-IfMissingFile -Path $NpmLocalCmd -Label "npm-local.cmd"
  Throw-IfMissingFile -Path $GulpLocalCmd -Label "gulp-local.cmd"
  Throw-IfMissingFile -Path $PackageBaseJson -Label "base\packages\packageBase.json"
  Throw-IfMissingFile -Path $NodeModulesTgz -Label "base\packages\node_modules-base.tgz"
  Throw-IfMissingDirectory -Path $CacheRoot -Label "base\cache"

  if (-not (Test-TarAvailable)) {
    throw "No se encontro tar en el sistema."
  }
}
# Descripcion: Convierte el nombre del proyecto a un nombre valido para package.json.
# Parametros de entrada: ProjectName.
# Salida: Nombre normalizado valido para package.json.
function Get-SafePackageName {
  param([string]$ProjectName)

  $safeName = $ProjectName.Trim().ToLowerInvariant()
  $safeName = $safeName -replace "\s+", "-"
  $safeName = $safeName -replace "[^a-z0-9\-_\.]", "-"
  $safeName = $safeName -replace "-+", "-"
  $safeName = $safeName.Trim("-")

  if ([string]::IsNullOrWhiteSpace($safeName)) {
    throw "El nombre del proyecto no es valido para package.json: $ProjectName"
  }

  return $safeName
}
# Descripcion: Copia packageBase.json como package.json del proyecto.
# Parametros de entrada: true.
function Apply-PackageBaseJson {
  param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectPath
  )

  $destinationPackageJson = Join-Path $ProjectPath "package.json"

  Copy-Item `
    -LiteralPath $PackageBaseJson `
    -Destination $destinationPackageJson `
    -Force
}
# Descripcion: Cambia solo la propiedad name del package.json del proyecto.
# Parametros de entrada: true.
function Set-PackageJsonName {
  param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectPath,

    [Parameter(Mandatory = $true)]
    [string]$ProjectName
  )

  $packageJsonPath = Join-Path $ProjectPath "package.json"

  Throw-IfMissingFile -Path $packageJsonPath -Label "package.json"

  $safeName = Get-SafePackageName -ProjectName $ProjectName
  $raw = Get-Content -LiteralPath $packageJsonPath -Raw

  if ($raw -match '"name"\s*:\s*"[^"]*"') {
    $raw = [regex]::Replace(
      $raw,
      '"name"\s*:\s*"[^"]*"',
      ('"name": "{0}"' -f $safeName),
      1
    )
  }
  else {
    throw "No se encontro la propiedad name en package.json"
  }

  Set-TextFileUtf8NoBom -Path $packageJsonPath -Content $raw
}
# Descripcion: Crea o actualiza el .npmrc del proyecto segun modo Online/Offline.
# Parametros de entrada: true.
function Set-ProjectNpmRc {
  param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectPath,

    [Parameter(Mandatory = $true)]
    [ValidateSet("Online", "Offline")]
    [string]$Mode
  )

  $npmrcPath = Join-Path $ProjectPath ".npmrc"
  $offlineValue = if ($Mode -eq "Offline") { "true" } else { "false" }

  $content = @"
cache=$CacheRoot
prefer-offline=true
offline=$offlineValue
fund=false
audit=false
progress=false
scripts-prepend-node-path=true
"@

  Set-TextFileUtf8NoBom -Path $npmrcPath -Content $content
}

# Descripcion: Crea o actualiza .vscode\settings.json para usar TypeScript local del proyecto.
# Parametros de entrada: true.
function Set-ProjectVsCodeSettings {
  param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectPath
  )

  $vscodePath = Join-Path $ProjectPath ".vscode"
  $settingsPath = Join-Path $vscodePath "settings.json"

  Ensure-Directory -Path $vscodePath

  $content = @"
{
  "files.exclude": {
    "**/.git": true,
    "**/.DS_Store": true,
    "**/bower_components": true,
    "**/coverage": true,
    "**/lib-amd": true,
    "src/**/*.scss.ts": true
  },
  "typescript.tsdk": ".\\node_modules\\typescript\\lib",
  "typescript.enablePromptUseWorkspaceTsdk": true
}
"@

  Set-TextFileUtf8NoBom `
    -Path $settingsPath `
    -Content $content

  Write-Info "Configurado: .vscode\settings.json"
}
# Descripcion: Lee el modo Online/Offline desde el .npmrc del proyecto.
# Parametros de entrada: ProjectPath.
# Salida: Modo de trabajo del proyecto: Online u Offline.
function Get-ProjectWorkMode {
  param([string]$ProjectPath)

  $npmrcPath = Join-Path $ProjectPath ".npmrc"

  if (-not (Test-Path -LiteralPath $npmrcPath -PathType Leaf)) {
    Set-ProjectNpmRc -ProjectPath $ProjectPath -Mode "Offline"
    return "Offline"
  }

  $raw = Get-Content -LiteralPath $npmrcPath -Raw

  if ($raw -match '(?im)^\s*offline\s*=\s*true\s*$') {
    return "Offline"
  }

  return "Online"
}
# Descripcion: Crea un acceso directo CMD dentro del proyecto para abrir la consola del kit directamente en ese proyecto.
# Parametros de entrada: true.
function New-ProjectConsoleLauncher {
  param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectPath
  )

  $launcherPath = Join-Path $ProjectPath "Consola_Desarrollador.cmd"

  $content = @"
@echo off
setlocal

  for %%I in ("%~dp0.") do set "PROJECT_DIR=%%~fI"
  for %%I in ("%PROJECT_DIR%\..\..") do set "KIT_ROOT=%%~fI"

powershell.exe -ExecutionPolicy Bypass -NoLogo -File "%KIT_ROOT%\scripts\Consola_Desarrollador.ps1" -ProjectPath "%PROJECT_DIR%"

endlocal
"@

  Set-TextFileUtf8NoBom `
    -Path $launcherPath `
    -Content $content

  Write-Info "Creado: Consola_Desarrollador.cmd"
}
# Descripcion: Cambia el modo de trabajo Online/Offline del proyecto.
# Parametros de entrada: true.
function Switch-ProjectWorkMode {
  param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectPath
  )

  Throw-IfMissingDirectory -Path $ProjectPath -Label "proyecto"

  $currentMode = Get-ProjectWorkMode -ProjectPath $ProjectPath
  $newMode = if ($currentMode -eq "Offline") { "Online" } else { "Offline" }

  Write-Info "Modo actual: $currentMode"
  Write-Info "Nuevo modo: $newMode"

  $confirm = Read-YesNo -Prompt "Quieres cambiar el modo del proyecto a '$newMode'?" -DefaultYes

  if (-not $confirm) {
    Write-WarnText "Operacion cancelada."
    return
  }

  Set-ProjectNpmRc -ProjectPath $ProjectPath -Mode $newMode

  Write-Host ""
  Write-Host "Modo cambiado correctamente a: $newMode" -ForegroundColor Green
}
# Descripcion: Ejecuta npm install usando el modo definido en .npmrc.
# Parametros de entrada: ProjectPath.
function Invoke-NpmInstallByMode {
  param([string]$ProjectPath)

  $mode = Get-ProjectWorkMode -ProjectPath $ProjectPath

  if ($mode -eq "Offline") {
    Invoke-ExternalCommand `
      -FilePath $NpmLocalCmd `
      -Arguments @("install", "--cache", $CacheRoot, "--prefer-offline", "--offline") `
      -WorkingDirectory $ProjectPath
  }
  else {
    Invoke-ExternalCommand `
      -FilePath $NpmLocalCmd `
      -Arguments @("install", "--cache", $CacheRoot, "--prefer-offline") `
      -WorkingDirectory $ProjectPath
  }
}

# Descripcion: Ejecuta la operacion Restore-NodeModulesBase.
# Parametros de entrada: ProjectPath.
function Restore-NodeModulesBase {
  param([string]$ProjectPath)

  Throw-IfMissingFile -Path $NodeModulesTgz -Label "base\packages\node_modules-base.tgz"

  if (-not (Test-TarAvailable)) {
    throw "No se encontro tar en el sistema."
  }

  Write-Step "Restaurando node_modules-base.tgz"
  Write-Info "Origen: $NodeModulesTgz"
  Write-Info "Destino: $ProjectPath"

  $nodeModulesPath = Join-Path $ProjectPath "node_modules"

  if (Test-Path -LiteralPath $nodeModulesPath -PathType Container) {
    Remove-Item -LiteralPath $nodeModulesPath -Recurse -Force
  }

  Push-Location $ProjectPath
  try {
    tar -xzf "$NodeModulesTgz"

    if ($LASTEXITCODE -ne 0) {
      throw "No se pudo restaurar node_modules-base.tgz. Codigo de salida: $LASTEXITCODE"
    }
  }
  finally {
    Pop-Location
  }

  if (-not (Test-Path -LiteralPath $nodeModulesPath -PathType Container)) {
    throw "No se encontro node_modules despues de extraer el TGZ."
  }

  Write-Info "node_modules restaurado correctamente"
}
# Descripcion: Crea un proyecto nuevo con Yeoman local y aplica la base del kit.
# Parametros de entrada: ProjectName, ComponentInfo, ComponentName.
function Invoke-YoCreateNewProject {
  param(
    [string]$ProjectName,
    [object]$ComponentInfo,
    [string]$ComponentName
  )

  $description = "$ComponentName description"

  $args = @(
    "@microsoft/sharepoint:app",
    "--skip-install",
    "--solution-name", $ProjectName,
    "--environment", $Environment,
    "--no-skip-feature-deployment",
    "--component-type", $ComponentInfo.ComponentType,
    "--component-name", $ComponentName,
    "--component-description", $description
  )

  if ($ComponentInfo.ComponentType -eq "webpart") {
    $args += @("--framework", "react")
  }
  else {
    $args += @(
      "--framework", "none",
      "--extension-type", $ComponentInfo.ExtensionType
    )
  }

  Invoke-ExternalCommand `
    -FilePath $YoLocalCmd `
    -Arguments $args `
    -WorkingDirectory $ProjectsRoot

  Remove-ProjectsRootYoRc

  $projectPath = Join-Path $ProjectsRoot $ProjectName

  if (-not (Test-Path -LiteralPath $projectPath -PathType Container)) {
    throw "No se ha creado la carpeta esperada del proyecto: $projectPath"
  }

  Apply-PackageBaseJson -ProjectPath $projectPath
  Set-PackageJsonName -ProjectPath $projectPath -ProjectName $ProjectName
  Set-ProjectNpmRc -ProjectPath $projectPath -Mode "Offline"
  Restore-NodeModulesBase -ProjectPath $projectPath
  New-ProjectConsoleLauncher -ProjectPath $projectPath
  Set-ProjectVsCodeSettings `
    -ProjectPath $projectPath

  Invoke-NpmInstallByMode -ProjectPath $projectPath

  Write-Step "Configurando certificado HTTPS de desarrollo"
  Write-Info "Si Windows solicita confiar en el certificado de localhost, acepta para habilitar las pruebas locales."

  Invoke-ExternalCommand `
    -FilePath $GulpLocalCmd `
    -Arguments @("trust-dev-cert") `
    -WorkingDirectory $projectPath

  Invoke-ExternalCommand `
    -FilePath $NpmLocalCmd `
    -Arguments @("run", "rebuild") `
    -WorkingDirectory $projectPath

  return $projectPath
}

# ============================================================
# LOGICA - NUEVO COMPONENTE
# ============================================================
# Descripcion: Comprueba si ya existe un componente con ese nombre en src\webparts o src\extensions del proyecto seleccionado.
# Parametros de entrada: true.
function Test-ComponentAlreadyExists {
  param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectPath,

    [Parameter(Mandatory = $true)]
    [object]$ComponentInfo,

    [Parameter(Mandatory = $true)]
    [string]$ComponentName
  )

  $resolvedProjectPath = (Resolve-Path -LiteralPath $ProjectPath).Path.TrimEnd('\')
  $rootName = if ($ComponentInfo.ComponentType -eq "webpart") { "webparts" } else { "extensions" }
  $componentPath = Join-Path $resolvedProjectPath (Join-Path "src\$rootName" $ComponentName)

  return (Test-Path -LiteralPath $componentPath -PathType Container)
}
# Descripcion: Anade un nuevo componente SPFx a un proyecto existente usando yo-local.cmd.
# Parametros de entrada: true.
function Invoke-YoAddComponentInExistingProject {
  param(
    [Parameter(Mandatory = $true)]
    [string]$ProjectPath,

    [Parameter(Mandatory = $true)]
    [object]$ComponentInfo,

    [Parameter(Mandatory = $true)]
    [string]$ComponentName
  )

  Throw-IfMissingFile -Path $YoLocalCmd -Label "yo-local.cmd"
  Throw-IfMissingDirectory -Path $ProjectPath -Label "proyecto"

  $resolvedProjectPath = (Resolve-Path -LiteralPath $ProjectPath).Path.TrimEnd('\')

  if (Test-ComponentAlreadyExists -ProjectPath $resolvedProjectPath -ComponentInfo $ComponentInfo -ComponentName $ComponentName) {
    throw "Ya existe un componente con ese nombre en el proyecto seleccionado: $ComponentName"
  }

  $description = "$ComponentName description"

  Write-Step "Anadiendo componente al proyecto existente"
  Write-Info "Proyecto: $resolvedProjectPath"
  Write-Info "Tipo: $($ComponentInfo.Label)"
  Write-Info "Componente: $ComponentName"
  Write-Info "Descripcion: $description"

  $args = @(
    "@microsoft/sharepoint:app",
    "--skip-install",
    "--environment", $Environment,
    "--component-type", $ComponentInfo.ComponentType,
    "--component-name", $ComponentName,
    "--component-description", $description
  )

  if ($ComponentInfo.ComponentType -eq "webpart") {
    $args += @("--framework", "react")
  }
  else {
    $args += @(
      "--framework", "none",
      "--extension-type", $ComponentInfo.ExtensionType
    )
  }

  Invoke-ExternalCommand `
    -FilePath $YoLocalCmd `
    -Arguments $args `
    -WorkingDirectory $resolvedProjectPath

  Write-Host ""
  Write-Host "Componente anadido correctamente." -ForegroundColor Green
}

# ============================================================

# LOGICA - ELIMINAR PROYECTO
# ============================================================
# Descripcion: Elimina fisicamente un proyecto completo previa confirmacion.
# Parametros de entrada: true.
function Remove-Project {
  param(
    [Parameter(Mandatory = $true)]
    [System.IO.DirectoryInfo]$Project
  )

  Write-Step "Eliminar proyecto"

  if ($null -eq $Project) {
    Write-ErrorText "No se ha recibido ningun proyecto."
    return $false
  }

  $projectPath = (Resolve-Path -LiteralPath $Project.FullName).Path
  $projectsRootResolved = (Resolve-Path -LiteralPath $ProjectsRoot).Path.TrimEnd('\')
  $projectPathResolved = $projectPath.TrimEnd('\')

  Write-WarnText "Se eliminara el proyecto completo:"
  Write-Info "Proyecto: $($Project.Name)"
  Write-Info "Ruta: $projectPathResolved"

  if (-not $projectPathResolved.StartsWith($projectsRootResolved, [System.StringComparison]::OrdinalIgnoreCase)) {
    Write-ErrorText "La ruta del proyecto no pertenece a ProjectsRoot. Operacion cancelada."
    Write-Info "ProjectsRoot: $projectsRootResolved"
    Write-Info "Proyecto: $projectPathResolved"
    return $false
  }

  if ($projectPathResolved -eq $projectsRootResolved) {
    Write-ErrorText "No se permite eliminar la carpeta raiz de proyectos."
    return $false
  }

  if (-not (Test-Path -LiteralPath $projectPathResolved -PathType Container)) {
    Write-WarnText "El proyecto ya no existe en disco."
    return $false
  }

  $confirm = Read-YesNo -Prompt "Quieres eliminar el proyecto '$($Project.Name)'?"

  if (-not $confirm) {
    Write-WarnText "Operacion cancelada."
    return $false
  }

  $typedName = Read-Host "Escribe el nombre del proyecto para confirmar"

  if ($typedName -ne $Project.Name) {
    Write-WarnText "Nombre incorrecto. Operacion cancelada."
    return $false
  }

  Remove-Item -LiteralPath $projectPathResolved -Recurse -Force

  Write-Host ""
  Write-Host "Proyecto eliminado correctamente: $($Project.Name)" -ForegroundColor Green

  return $true
}

# ============================================================
